Map<String, double> avaliableCars = {
  'Corsa': 10.000,
  'Uno': 12.500,
  'Marea': 15.000,
  'Parati': 20.000,
};

Map<String, double> cars_sold = {};

String typePayament = """\n
[D] Debito
[C] Credito
[P] Pix
""";

String menu = """\n
[C] Comprar
[V] Vender
[S] Sair
""";

String timePayament = """\n
[1] A vista
[2] 3 vezes
[3] 6 vezes
[4] 9 vezes
[5] 12 vezes
""";
