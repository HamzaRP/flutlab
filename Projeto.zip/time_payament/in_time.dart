String in_time() {
  return 'Pagamento realizado a vista';
}
