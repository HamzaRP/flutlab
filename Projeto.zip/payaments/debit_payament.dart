String debitPayament() {
  return 'Pagamento realizado por débito';
}
